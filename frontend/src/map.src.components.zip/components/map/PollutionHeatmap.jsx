function PollutionHeatmap() {

  const zones = [

    {
      top: "25%",
      left: "35%",
      color: "bg-green-500",
      size: "w-24 h-24",
    },

    {
      top: "40%",
      left: "60%",
      color: "bg-yellow-500",
      size: "w-28 h-28",
    },

    {
      top: "55%",
      left: "45%",
      color: "bg-orange-500",
      size: "w-32 h-32",
    },

    {
      top: "30%",
      left: "75%",
      color: "bg-red-500",
      size: "w-24 h-24",
    },

  ];

  return (

    <>
      {zones.map((zone, index) => (

        <div
          key={index}
          className={`
            absolute
            rounded-full
            blur-3xl
            opacity-30
            ${zone.color}
            ${zone.size}
          `}
          style={{
            top: zone.top,
            left: zone.left,
          }}
        />

      ))}
    </>

  );
}

export default PollutionHeatmap;
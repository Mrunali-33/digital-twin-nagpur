import { Circle } from "react-leaflet";

function GISOverlays() {

  const pollutionZones = [

    {
      center: [21.1458, 79.0882],
      radius: 300,
      color: "#22c55e",
    },

    {
      center: [21.1485, 79.0915],
      radius: 450,
      color: "#eab308",
    },

    {
      center: [21.1425, 79.0950],
      radius: 550,
      color: "#f97316",
    },

    {
      center: [21.1400, 79.1000],
      radius: 650,
      color: "#ef4444",
    },

  ];

  const floodZones = [

    {
      center: [21.1500, 79.0820],
      radius: 350,
      color: "#22c55e",
    },

    {
      center: [21.1360, 79.0900],
      radius: 450,
      color: "#eab308",
    },

    {
      center: [21.1320, 79.1020],
      radius: 550,
      color: "#ef4444",
    },

  ];

  return (
    <>
      {/* Pollution */}

      {pollutionZones.map((zone, index) => (

        <Circle
          key={`pollution-${index}`}
          center={zone.center}
          radius={zone.radius}
          pathOptions={{
            color: zone.color,
            fillColor: zone.color,
            fillOpacity: 0.18,
            weight: 2,
          }}
        />

      ))}

      {/* Flood */}

      {floodZones.map((zone, index) => (

        <Circle
          key={`flood-${index}`}
          center={zone.center}
          radius={zone.radius}
          pathOptions={{
            color: zone.color,
            fillColor: zone.color,
            fillOpacity: 0.08,
            dashArray: "6",
            weight: 3,
          }}
        />

      ))}
    </>
  );
}

export default GISOverlays;

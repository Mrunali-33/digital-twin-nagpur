function FloodZones() {

  const zones = [

    {
      top: "60%",
      left: "30%",
      color: "#22c55e",
    },

    {
      top: "45%",
      left: "50%",
      color: "#eab308",
    },

    {
      top: "35%",
      left: "70%",
      color: "#ef4444",
    },

  ];

  return (

    <>
      {zones.map((zone, index) => (

        <div
          key={index}
          className="absolute z-[900]"
          style={{
            top: zone.top,
            left: zone.left,
          }}
        >

          <div
            className="w-24 h-24 rounded-full border-4"
            style={{
              borderColor: zone.color,
            }}
          />

        </div>

      ))}
    </>

  );
}

export default FloodZones;